# Mineflayer AFK Bot – Minecraft 26.2

Für JustRunMy.App.

## Environment Variables

MC_HOST=deine-server-ip
MC_PORT=25565
BOT_USERNAME=AFK-Bot
MC_AUTH=offline
MC_VERSION=26.2

## Start

npm start

Node.js 22+ wird benötigt.

Diese Version verwendet ein vorgepacktes 26.2 Mineflayer-Release, damit npm install keine Prismarine-Git-Abhängigkeiten per SSH klonen muss.
